import face_recognition
image = face_recognition.load_image_file("Taco.JPG")
face_landmarks_list = face_recognition.face_landmarks(image)
print("檢測到的臉部特徵點：")
for i, face_landmarks in enumerate(face_landmarks_list):
    print(f"人臉 {i + 1} 特徵點:")
    for feature, points in face_landmarks.items():
        print(f"  {feature}: {points}")