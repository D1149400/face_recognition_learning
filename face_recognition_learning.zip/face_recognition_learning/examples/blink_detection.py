import face_recognition
import cv2
import time
from scipy.spatial import distance as dist

EYES_CLOSED_SECONDS = 5

def main():
    closed_count = 0
    video_capture = cv2.VideoCapture(0)
    asleep = False  # 用於追蹤是否處於「EYES CLOSED」狀態

    while True:
        ret, frame = video_capture.read()
        if not ret:
            print("無法讀取影像，請檢查相機")
            break

        # 調整影像大小以加快處理速度
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = small_frame[:, :, ::-1]

        # 獲取臉部特徵點
        face_landmarks_list = face_recognition.face_landmarks(rgb_small_frame)
        
        for face_landmark in face_landmarks_list:
            left_eye = face_landmark['left_eye']
            right_eye = face_landmark['right_eye']

            # 計算眼睛閉合比 (EAR)
            ear_left = get_ear(left_eye)
            ear_right = get_ear(right_eye)

            # 判斷眼睛是否閉合
            closed = ear_left < 0.2 and ear_right < 0.2
            if closed:
                closed_count += 1
            else:
                closed_count = 0

            # 如果眼睛閉上超過設定秒數，顯示「EYES CLOSED」
            if closed_count >= EYES_CLOSED_SECONDS and not asleep:
                print("EYES CLOSED")
                asleep = True  # 進入「EYES CLOSED」狀態

            # 檢查空白鍵來重置狀態
            if asleep and cv2.waitKey(1) == 32:  # 空白鍵 ASCII 是 32
                print("EYES OPENED")
                asleep = False  # 重置為「EYES OPENED」狀態
                closed_count = 0  # 重置閉眼計數

        # 顯示影像
        cv2.imshow('Video', small_frame)

        # 按 q 鍵退出
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    video_capture.release()
    cv2.destroyAllWindows()

def get_ear(eye):
    # 計算眼睛的 EAR
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

if __name__ == "__main__":
    main()
